from project.car import Car

class SportsCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10
