from .animal import Animal
from abc import ABC, abstractmethod
from ..food import *


class Mammal(Animal, ABC):
    WEIGHT_INCREASE = 0
    FOODS = []

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight)
        self.living_region = living_region

    @abstractmethod
    def make_sound(self):
        pass

    def __repr__(self):
        return f"{self.__class__.__name__} [{self.name}, {self.weight}, {self.living_region}, {self.food_eaten}]"


class Mouse(Mammal):
    WEIGHT_INCREASE = 0.1
    FOODS = [Vegetable, Fruit]

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Squeak"


class Dog(Mammal):
    WEIGHT_INCREASE = 0.4
    FOODS = [Meat]

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Woof!"


class Cat(Mammal):
    WEIGHT_INCREASE = 0.30
    FOODS = [Vegetable, Meat]

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Meow"


class Tiger(Mammal):
    WEIGHT_INCREASE = 1
    FOODS = [Meat]

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "ROAR!!!"
