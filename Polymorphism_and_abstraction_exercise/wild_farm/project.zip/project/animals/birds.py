from .animal import Animal
from abc import ABC, abstractmethod
from ..food import *


class Bird(Animal, ABC):
    WEIGHT_INCREASE = 0
    FOODS = []

    def __init__(self, name, weight, wing_size):
        super().__init__(name, weight)
        self.wing_size = wing_size

    @abstractmethod
    def make_sound(self):
        pass

    def __repr__(self):
        return f"{self.__class__.__name__} [{self.name}, {self.wing_size}, {self.weight}, {self.food_eaten}]"


class Owl(Bird):
    WEIGHT_INCREASE = 0.25
    FOODS = [Meat]

    def __init__(self, name, weight, wing_size):
        super().__init__(name, weight, wing_size)

    def make_sound(self):
        return "Hoot Hoot"


class Hen(Bird):
    WEIGHT_INCREASE = 0.35
    FOODS = [Vegetable, Fruit, Meat, Seed]

    def __init__(self, name, weight, wing_size):
        super().__init__(name, weight, wing_size)

    def make_sound(self):
        return "Cluck"


