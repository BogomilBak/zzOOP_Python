from abc import ABC, abstractmethod


class Animal(ABC):
    FOODS = []
    WEIGHT_INCREASE = 0

    def __init__(self, name, weight):
        self.name = name
        self.weight = weight
        self.food_eaten = 0

    @abstractmethod
    def make_sound(self):
        pass

    def feed(self, food):
        if food.__class__ not in self.FOODS:
            return self.error_message(food)
        self.weight += self.WEIGHT_INCREASE * food.quantity
        self.food_eaten += food.quantity

    def error_message(self, food):
        return f"{self.__class__.__name__} does not eat {food.__class__.__name__}!"
